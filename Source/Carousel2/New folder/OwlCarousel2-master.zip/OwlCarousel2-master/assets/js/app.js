// Highlight Code
hljs.configure({tabReplace: '  '}); // 4 spaces
hljs.initHighlightingOnLoad();
